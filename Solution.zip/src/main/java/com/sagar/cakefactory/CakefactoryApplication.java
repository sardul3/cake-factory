package com.sagar.cakefactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CakefactoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(CakefactoryApplication.class, args);
	}

}
