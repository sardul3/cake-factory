package com.sagar.cakefactory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CakefactoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
